public class Chopstick {
	private final int ID;
	// hint: use a local variable to indicate whether the chopstick is free
	// (lying on the table), e.g. private boolean free;

	private boolean free;

	Chopstick(int id) {
		this.ID = id;
		this.free = true;

	}

	synchronized boolean take(long time) {
		while (!isFree()) {
			try {
				wait(time);
				return isFree();
			} catch (InterruptedException e) {
				System.out.println(e);
			}
		}
		toggleFree();
		this.notifyAll();
		return isFree();
	}

	synchronized void release() {
		while (isFree()) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		toggleFree();
		this.notifyAll();
	}

	public int getID() {
		return (ID);
	}

	public boolean isFree() {
		return this.free;
	}

	private void toggleFree() {
		this.free = !this.free;
	}

}
