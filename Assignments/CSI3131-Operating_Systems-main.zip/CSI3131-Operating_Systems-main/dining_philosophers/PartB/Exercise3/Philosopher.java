public class Philosopher extends Thread implements Runnable {
	private GraphicTable table;
	private Chopstick left;
	private Chopstick right;
	private int ID;
	final int timeThink_max = 5000;
	final int timeNextFork = 100;
	final int timeEat_max = 5000;

	private int counter;
	private boolean gaveUp;

	Philosopher(int ID, GraphicTable table, Chopstick left, Chopstick right) {
		this.ID = ID;
		this.table = table;
		this.left = left;
		this.right = right;
		setName("Philosopher " + ID);
		this.counter = 0;
		this.gaveUp = false;
	}

	@Override
	public void run() {
		while (true) {
			dine();
		}
	}

	private void dine() {
		try {
			think();

			// Let's try to get the left chopstick
			takeChopstick(Side.LEFT);

			// I'll wait a bit before I try to get the next chopstick (it's philosopher's
			// etiquette)
			etiquette();

			// Ok, enough etiquette nonesense, now I need my right chopstick
			takeChopstick(Side.RIGHT);

			// Sweet taste of steamed rice....
			eat();

			// Ok, I am really full now
			finishEating();

		} catch (InterruptedException e) {
			// System.out.println(e.getStackTrace().toString());
			finishEating();
			return;
		}

	}

	private void think() {
		// Tell the table GUI that I am thinking
		table.isThinking(ID);
		// Print to console that I am thinking
		System.out.println(getName() + " thinks");

		// Let the thread sleep (in order to simulate thinking time)
		try {
			sleep((long) (Math.random() * timeThink_max));
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		// Done with thinking
		System.out.println(getName() + " finished thinking");

		// and now I am hungry!
		System.out.println(getName() + " is hungry");

		// Tell the GUI I am hungry...
		table.isHungry(ID);
	}


	private void etiquette() {
		try {
			sleep(timeNextFork);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	private void takeChopstick(Side side) throws InterruptedException {

		// Let's try to get the left chopstick
		System.out.println(getName() + " wants " + side.name() + " chopstick");
		Chopstick toTake = left;
		switch (side) {
			case LEFT:
				toTake = left;
				break;
			case RIGHT:
				toTake = right;
				break;
		}
		updateGaveUp(toTake.take(timeNextFork * 10000));
		table.takeChopstick(ID, toTake.getID());
		System.out.println(getName() + " got " + side + " chopstick: " + toTake.getID());
		this.counter++;
	}



	private void eat() {
		if (counter != 2 || gaveUp) {
			return;
		}
		System.out.println(getName() + " eats");
		try {
			sleep((long) (Math.random() * timeEat_max));
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	private void finishEating() {
		System.out.println(getName() + " finished eating");

		// I just realized I did not wash these chopsticks
		// and the philosopher on my right is coming down with a flu
		releaseChopstick(Side.LEFT);
		releaseChopstick(Side.RIGHT);

	}

	private void releaseChopstick(Side side) {

		// Let's try to get the left chopstick
		Chopstick toRelease = left;
		switch (side) {
			case LEFT:
				toRelease = left;
				break;
			case RIGHT:
				toRelease = right;
				break;
		}

		// Tell the GUI that I took the left chopstick
		if (!toRelease.isFree()) {
			toRelease.release();
			table.releaseChopstick(ID, toRelease.getID());
			this.counter--;
		}
		System.out.println(getName() + " released " + side + " chopstick");
	}

	public synchronized void updateGaveUp(boolean tooLong) throws InterruptedException {
		this.gaveUp = tooLong;
		if (this.gaveUp) {
			String message = getName() + " watied too long for a chopstick. GAVE UP.";
			System.out.println(message);
			throw new InterruptedException(message);
		}
		notifyAll();
	}

	private enum Side {
		LEFT, RIGHT;
	}
}
