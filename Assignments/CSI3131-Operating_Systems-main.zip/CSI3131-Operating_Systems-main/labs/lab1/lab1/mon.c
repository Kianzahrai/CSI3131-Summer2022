#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>

/* Its all done in the main function */
int main(int argc, char **argv)
{
    char *program;
    char pidstring1[32];
    int pid1, pid2;

    if (argc != 2)
    {
        printf("Usage: mon fileName\n where fileName is an executable file.\n");
        exit(-1);
    }
    else
        program = argv[1];      /* This is the program to monitor */

    pid1 = fork();      /* fork another process */
    sprintf(pidstring1, "%d", pid1);        /* Convert the pid number to a character string */
    if (pid1 == -1)     /* Error has occurred */
    {
        printf("First fork failed.\n");
        exit(-1);
    }
    else if (pid1 == 0)     /* Child process */
    {
        printf("First fork running");
        execl(program, program, NULL);
        exit(-1);
    }
    
    /* In the parent process */
    pid2 = fork();      /* Another child process to run procmon */
    if (pid2 == -1)     /* Error has occurred */
    {
        printf("Second fork failed.\n");
        kill(pid1, SIGKILL);        /* Kills the other child */
        exit(-1);
    }
    else if (pid2 == 0)     /* In the child process start up the procmon program */
    {
        printf("running procmon fork");
        execl("procmon", "procmon", pidstring1, NULL);
    }

    sleep(20);      /* Wait 20 seconds */
    printf("Killing %s\n", program);
    kill(pid1, SIGKILL);        /* Finished with the first child */
    sleep(2);
    printf("Killing procmon.\n");       /* Finished with procmon */
    kill(pid2, SIGKILL);

    return (0);
}
