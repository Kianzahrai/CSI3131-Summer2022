public class FibonacciPrinter implements Runnable {

    private final int ID;
    private final int amount;


    FibonacciPrinter(int ID, int amount) {
        this.ID = ID;
        this.amount = amount;
    }


    synchronized void printFibonacci() {
        System.out.println("FIBONACCI PRINTER: Spawning child fibonacci printer thread ");
        FibonacciGenerator gen = new FibonacciGenerator(amount);
        gen.start();
        try {
            gen.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Sequence.acquireQueue();
        Sequence.printQueue();
        Sequence.releaseQueue();
    }

    @Override
    public void run() {
        while (true) {
            StringBuilder sb = new StringBuilder();
            sb.append("*****************************************************");
            sb.append(" Running Fibonacci Printer Thread ");
            sb.append("*****************************************************");
            System.out.println(sb.toString());
            printFibonacci();
            return;
        }
    }

}
