import java.lang.System.Logger;
import java.util.LinkedList;
import java.util.Queue;

public class Primes extends Thread {

    Logger logger = System.getLogger(Primes.class.getName());

    private final int ID;
    private int bound;
    private static Queue<Integer> primeNums = new LinkedList<>();
    private boolean isBusy;

    Primes(int ID, int bound) {
        this.ID = ID;
        this.bound = bound;
        isBusy = false;
    }

    private void addPrimes() {
        synchronized (primeNums) {

            // By definition, 1 is not a prime number.
            int i = 2;

            while (i <= bound) {
                System.out.println(i);
                primeNums.add(i);
                i = nextPrime(i);
            }
        }
    }

    private int nextPrime(int i) {
        while (!isPrime(++i)) {
            continue;
        }
        return i;
    }

    private boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void run() {
        while (true) {
            StringBuilder sb = new StringBuilder();
            sb.append("*****************************************************");
            sb.append(" Running Primes Generator Thread ");
            sb.append("*****************************************************");
            System.out.println(sb.toString());
            addPrimes();
            return;
        }
    }



}
