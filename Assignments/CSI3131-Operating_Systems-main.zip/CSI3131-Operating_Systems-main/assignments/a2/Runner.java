import java.util.Scanner;

public class Runner implements Runnable {

    private static Scanner scanner = new Scanner(System.in);

    private Runner() {}

    public static void main(String[] args) {

        Runner runner = new Runner();
        runner.run();
        scanner.close();

    }

    @Override
    public void run() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n*****************************************************");
        sb.append(" Retrieving initialization input ");
        sb.append("*****************************************************\n");
        System.out.println(sb.toString());


        while (true) {
            int input = getIntegerInput();
            Process process = getProcessInput();
            switch (process) {
                case PRIMES:
                    Primes primes = new Primes(0, input);
                    primes.start();
                    break;
                case FIBONACCI:
                    FibonacciPrinter fibonacciPrinter = new FibonacciPrinter(0, input);
                    Thread thread = new Thread(fibonacciPrinter);
                    thread.start();
                    break;
                default:
                    System.exit(0);
                    break;
            }
            return;
        }

    }



    private static int getIntegerInput() {
        // while statement that keeps asking for input when args is < 0
        System.out.println("\nEnter an integer greater than 0: ");;
        int num;
        while (true) {
            System.out.print("Input: ");
            try {
                num = scanner.nextInt();
                if (num > 0) {
                    break;
                }
            } catch (Exception e) {
                System.out.println("\nInvalid input. Please enter an integer greater than 0: ");
                scanner.nextLine();
            }
        }
        System.out.println("\n");

        return num;
    }

    private static Process getProcessInput() {
        StringBuilder sb = new StringBuilder();
        sb.append("\nEnter one of the following: \n");
        sb.append("- \"P\" for Primes process\n");
        sb.append("- \"F\" for Fibonnaci process\n");
        sb.append("- \"Q\" to quit\n");
        System.out.println(sb.toString());

        while (true) {
            System.out.print("Input: ");
            scanner = new Scanner(System.in);
            String process = scanner.next().toUpperCase();
            switch (process) {
                case "P":
                    return Process.PRIMES;
                case "F":
                    return Process.FIBONACCI;
                case "Q":
                    return Process.QUIT;
                default:
                    System.out.println("Invalid input. Try again.");
                    continue;
            }
        }
    }

    private enum Process {
        PRIMES("P"), FIBONACCI("F"), QUIT("Q");

        private String input;

        Process(String input) {
            this.input = input;
        }
    }

}
