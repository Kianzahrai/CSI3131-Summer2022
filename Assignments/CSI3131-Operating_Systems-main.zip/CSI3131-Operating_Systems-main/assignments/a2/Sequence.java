import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Sequence {

    private static Semaphore lock = new Semaphore(1);
    private static Queue<Integer> fibonacciNums = new LinkedList<>();

    private Sequence() {}

    public static Queue<Integer> acquireQueue() {
        try {
            lock.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return fibonacciNums;
    }

    public static Queue<Integer> releaseQueue() {
        lock.release();
        return fibonacciNums;
    }

    public static void enqueueElement(int i) {
        fibonacciNums.add(i);
    }

    public static void printQueue() {
        for (int elem : fibonacciNums) {
            System.out.println(elem);
        }
    }

    public static void clearQueue() {
        fibonacciNums.clear();
    }

}
