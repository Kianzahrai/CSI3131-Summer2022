public class FibonacciGenerator extends Thread {

    private final int amount;

    FibonacciGenerator(int amount) {
        this.amount = amount;
    }

    synchronized void generateFibonacciNums() {
        System.out.println("FIBONACCI GENERATOR: Generating Fibonacci Numbers");
        Sequence.acquireQueue();
        Sequence.clearQueue();

        int i = 0;
        int j = 1;
        int sum;
        int counter = amount;

        while (counter > 0) {
            sum = i + j;
            Sequence.enqueueElement(i + j);
            i = j;
            j = sum;
            counter--;
        }
        System.out.println("FIBONACCI GENERATOR: Competed Generating Fibonacci Numbers");
        // Sequence.releaseQueue();
    }

    @Override
    public void run() {
        while (true) {
            StringBuilder sb = new StringBuilder();
            sb.append("*****************************************************");
            sb.append(" Running Fibonacci Generator Thread ");
            sb.append("*****************************************************");
            System.out.println(sb.toString());
            generateFibonacciNums();
            return;
        }
    }

}
