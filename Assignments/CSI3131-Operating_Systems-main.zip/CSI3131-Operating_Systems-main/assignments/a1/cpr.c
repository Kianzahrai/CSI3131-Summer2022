/* ------------------------------------------------ ------------
File: cpr.c

Last name: Zahrai
First name: Kian
Student number: 300098986

Last name: Bolton
First name: Billy
Student number: 6411144

Description: This program contains the code for creation
 of a child process and attach a pipe to it.
	 The child will send messages through the pipe
	 which will then be sent to standard output.

Explanation of the zombie process
(point 5 of "To be completed" in the assignment):

A process that has terminated, but whose parent has not yet called wait(), is known as a zombie process.
All processes transition to this state when they terminate, but generally they exist as zombies only briefly.
We observe the zombie process when the shell prints the state of the process as <defunct>.
This <defunct> zombie state is only present until its parent process calls wait(). Therefore, this state occurs prior between closing the child but before closing its respective parent.
Each parent will sleep(10) for every child process that is closed.
This sleep time helps to observe the <defunct> zombie state by running the CLI command `ps -u ${username}` command.
Using the exit(fd[arg]) command could have been used instead however the close(fd[arg]) sleep(10) pattern allows us to observe the cascading termination process from children to root process.

------------------------------------------------------------- */
#include <stdio.h>
#include <sys/select.h>
#include <unistd.h>
#include <string.h>

/* Prototype */
void createChildAndRead(int);

/* -------------------------------------------------------------
Function: main
Arguments:
	int ac	- number of command arguments
	char **av - array of pointers to command arguments
Description:
	Extract the number of processes to be created from the
	Command line. If an error occurs, the process ends.
	Call createChildAndRead to create a child, and read
	the child's data.
-------------------------------------------------- ----------- */

int main(int ac, char **av)
{
	int processNumber;

	if (ac == 2)
	{
		if (sscanf(av[1], "%d", &processNumber) == 1)
		{
			createChildAndRead(processNumber);
		}
		else
			fprintf(stderr, "Cannot translate argument\n");
	}
	else
		fprintf(stderr, "Invalid arguments\n");
	return (0);
}

/* ------------------------------------------------ -------------
Function: createChildAndRead
Arguments:
	int prcNum - the process number
Description:
	Create the child, passing prcNum-1 to it. Use prcNum
	as the identifier of this process. Also, read the
	messages from the reading end of the pipe and sends it to
	the standard output (df 1). Finish when no data can
	be read from the pipe.
-------------------------------------------------- ----------- */

void createChildAndRead(int prcNum)
{
	//-- Declare Variables --
	int fd[2];	   // Allocating space in pipe (where fd[0] points to the read end of pipe and fd[1] points to the write end of pipe)
	int PID;	   // Declaring process number as integer type
	char *tmp[64]; // Specifying char* (explicitly stating a sequence of characters), because just putting char caused character issues.
	char *inputBuffer[1024];
	// Specifying the memory allocated for the the inputBuffer, which is where we stored what is being read from the pipe.

	// Create pipe AND Checking for Pipe Error
	if (pipe(fd) < 0)
	{
		fprintf(stderr, "Pipe error\n");
		return -1;
	}

	// When argument is 1, a child process will not be created
	if (prcNum == 1)
	{
		printf("Process %d starting \n", prcNum);
		sleep(5); // The wait period between starting and terminating the last process
		printf("Process %d terminating \n", prcNum);
	}
	else if (prcNum > 1) // If process number is not 1 (the final process), continue to fork and create children
	{
		PID = fork();
	}

	if (PID < 0) // Checking for Forking error
	{
		fprintf(stderr, "Fork error\n");
		return -1;
	}

	if (PID == 0) //-- CHILD Process --
	{
		close(fd[0]); // Close reading end of pipe, child will be doing purely writing

		// Converting dynamic text containing process number to a string
		sprintf(tmp, "Process %d starting \n", prcNum); // To help form zombie process explanation: (From PID: %d)
		write(fd[1], tmp, sizeof(inputBuffer));			// Writes into the writing end of the pipe

		/** Notes for 'dup2(x,y)' usage:
		- Using multiple descriptors so that we do not overwrite before being read
		- With dup2, we are attaching the writing end of the pipe to our prcNum descriptor
		- Needed to find unused file descriptors in memory to work accordingly in order, therefore increased descriptor number of second argument
		**/
		dup2(fd[1], (prcNum + 10)); // changes where write goes to (Where in memory you want to write to: which descriptor you want to use)

		close(fd[1]);

		//-- Declaration of "execvp" arguments --
		sprintf(inputBuffer, "%d", prcNum - 1); // Convert integer to string type
		// printf("inputBuffer %s\n", inputBuffer);
		char *args[3];
		args[0] = "./cpr"; // Name of file created (Executable)
		args[1] = inputBuffer;
		args[2] = NULL;

		/** Notes for 'execvp(x,y)' usage:
		- Duplicates program with decremented argument input from the line for "Declaration of "execvp" arguments"
		- Similar to recursion, as it recursively calls program with arguments given (FirstParent --> FirstChild (SecondParent) --> SecondChild(ThirdParent) --> Third...., then Ends and traverses back up to FirstParent)
				- Check the assignment documentation for necessity of use
		**/
		int read;
		if ((read = execvp(args[0], args)) < 0) // Also checks for execvp() error
		{
			fprintf(stderr, "Execvp error\n");
		}
	}
	else //-- PARENT Process --
	{
		close(fd[1]); // Close writing end of pipe
		// exit(fd[1]);

		// Reading and printing the contents from the reading end of the pipe
		while (read(fd[0], inputBuffer, sizeof(inputBuffer)) > 0)
		{
			printf("%s", inputBuffer);
		}

		sleep(10);									 // Delay set to observe zombie processes: after EACH process termination
		printf("Process %d terminating \n", prcNum); // To help form zombie process explanation: (From PID: %d)
		close(fd[0]);
		// exit(fd[0]);
	}
	return 0;
}