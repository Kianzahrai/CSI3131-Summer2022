
// @formatter:off
/**
 * Course: CSI3131 - Operating Systems
 * Professor: Dr. Fadi Malek - Malek@uOttawa.ca
 * Semester: Summer 2022
 * 
 * @author Kian Zahrai - 300098986
 * @author Billy Bolton - 6411144
 * @since 2022-06-26
 */
// @formatter:on

import java.util.concurrent.Semaphore;

/**
 * The OfficeHours class is a wrapper class for the TeachingAssistant class. The static methods in
 * this class make accessing the TeachingAssistant as a shared resource easier and more memory
 * efficient.
 */
public class OfficeHours {

    private static TeachingAssistant ta;
    private static Thread taThread;

    private static Semaphore line;

    // This is a private default constructor. It prevents the class from being instantiated.
    private OfficeHours() {}

    /**
     * The `start()` function creates a new `Semaphore` object with a capacity of 3, creates a new
     * `TeachingAssistant` object, and starts the `TeachingAssistant` thread
     */
    public static void start() {
        line = new Semaphore(3);

        ta = new TeachingAssistant();
        taThread = new Thread(ta);
        taThread.start();
    }

    /**
     * The number of students in line.
     * 
     * @return The number of students in line.
     */
    public static synchronized int getLineSize() {
        return 3 - line.availablePermits();
    }

    /**
     * If the number of available permits is 0, then the line is full.
     * 
     * @return True if the number of available permits in the line semaphore is 0.
     */
    public static synchronized boolean isLineFull() {
        return line.availablePermits() == 0;
    }

    /**
     * If the number of available permits is 3, then the line is empty.
     * 
     * @return True if the number of available permits in the line semaphore is 3.
     */
    public static synchronized boolean isLineEmpty() {
        return line.availablePermits() == 3;
    }

    /**
     * Notify all the ta object of changes.
     */
    public static synchronized void notifyTa() {
        synchronized (ta) {
            ta.notifyAll();
        }
    }

    /**
     * If the TA is available, return true, otherwise return false.
     * 
     * @return The boolean value of the isAvailable() method.
     */
    public static synchronized boolean isTaAvailable() {
        return ta.isAvailable();
    }

    /**
     * If the TA is sleeping, return true, otherwise return false.
     * 
     * @return The boolean value of the isAsleep() method.
     */
    public static boolean isTaSleeping() {
        return ta.isAsleep();
    }

    /**
     * If the TA is with a student, return true, otherwise return false.
     * 
     * @return The boolean value of the isWithStudent() method.
     */
    public static boolean isTaWithStudent() {
        return ta.isWithStudent();
    }

    /**
     * The function acquires the TA by setting the TA's is with student status to true and notify
     * the waiting ta thread.
     */
    public static void acquireTa() {
        synchronized (ta) {
            ta.setIsWithStudent(true);
            ta.notifyAll();
        }
    }

    /**
     * If the TA is with a student, then release the TA and notify the waiting ta thread.
     */
    public static void releaseTa() {
        synchronized (ta) {
            ta.setIsWithStudent(false);
            ta.notifyAll();
        }
    }

    /**
     * Acquires a permit from the semaphore. If there are no permits available, the thread will wait
     * until one is available
     */
    public static void acquireChair() {
        try {
            synchronized (line) {
                line.acquire();
                line.notifyAll();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * If there's a chair available, take it. If not, wait until there is one.
     */
    public static void releaseChair() {
        synchronized (line) {
            line.release();
            line.notifyAll();
        }
    }

    public static String hallwayState() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n\n");
        sb.append("*******************************\n");
        sb.append(" Hallway State \n");
        sb.append("*******************************\n");
        sb.append("\n");
        sb.append("Line Semaphore: " + line.availablePermits() + "\n");
        sb.append("Queue isFull: " + isLineFull() + "\n");
        sb.append("\n");
        sb.append("\n\n");

        return sb.toString();
    }

}
