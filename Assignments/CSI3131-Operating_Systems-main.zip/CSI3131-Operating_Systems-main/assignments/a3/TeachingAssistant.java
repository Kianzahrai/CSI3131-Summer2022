
// @formatter:off
/**
 * Course: CSI3131 - Operating Systems
 * Professor: Dr. Fadi Malek - Malek@uOttawa.ca
 * Semester: Summer 2022
 * 
 * @author Kian Zahrai - 300098986
 * @author Billy Bolton - 6411144
 * @since 2022-06-26
 */
// @formatter:on

import java.util.concurrent.Semaphore;

/**
 * The TeachingAssistant class implements the Runnable interface so that it can be used to start a
 * thread. The TeachingAssistant will naps while the Hallway.line is empty. The TeachingAssistant
 * will wake up when the Hallway.line is not empty. The TeachingAssistant will help students one by
 * one until the Hallway.line is empty. The TeachingAssistant will then go back to napping.
 */
public class TeachingAssistant implements Runnable {


    private final Semaphore isAvailable;
    private final Semaphore sleeping;
    private final Semaphore isWithStudent;


    /**
     * The TeachingAssistant constructor instantiates its semaphores, isAvailable, sleeping, and
     * isWithStudent.
     */
    public TeachingAssistant() {
        this.isAvailable = new Semaphore(0);
        this.sleeping = new Semaphore(0);
        this.isWithStudent = new Semaphore(1);
    }


    /**
     * If the available permits is equal to 1, then the TeachingAssistant is available.
     * 
     * @return Whether or not the TeachingAssistant is available.
     */
    public boolean isAvailable() {
        return this.isAvailable.availablePermits() == 1;
    }

    /**
     * If the number of available permits is 0, then the TeachingAssistant is asleep.
     * 
     * @return Whether or not the TeachingAssistant is asleep.
     */
    public boolean isAsleep() {
        return this.sleeping.availablePermits() == 0;
    }


    /**
     * If the number of available permits is 0, then the professor is with a student.
     * 
     * @return Whether or not the TeachingAssistant is with a student.
     */
    public boolean isWithStudent() {
        return this.isWithStudent.availablePermits() == 0;
    }

    /**
     * If the TA is available, then release the semaphore. If the TA is not available, then acquire
     * the semaphore
     * 
     * @param available The boolean value used to set whether the TA is available or not.
     */
    public synchronized void setIsAvailable(boolean available) {
        try {
            if (available && !this.isAvailable()) {
                this.isAvailable.release();
            }
            if (!available && this.isAvailable()) {
                this.isAvailable.acquire();
            }
            notifyAll();
            // System.out.println("TA is available: " + isAvailable());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * If the TA is asleep, wake up. If the TA is awake, go to sleep.
     * 
     * @param asleep The value used to set whether the TA should be asleep or not.
     */
    public synchronized void setAsleep(boolean asleep) {
        try {
            if (asleep && !this.isAsleep()) {
                this.sleeping.acquire();
                this.isAvailable.acquire();
            }
            if (!asleep && this.isAsleep()) {
                this.sleeping.release();
                this.isAvailable.release();
            }
            notifyAll();
            // System.out.println("TA is asleep: " + isAsleep());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * If the TA is with a student, then the TA is not available. If the TA is not with a student,
     * then the TA is available
     * 
     * @param withStudent boolean value that determines whether the TA is with a student or not
     */
    public synchronized void setIsWithStudent(boolean withStudent) {
        try {
            if (withStudent && !this.isWithStudent()) {
                this.isWithStudent.acquire();
                this.isAvailable.acquire();
            }
            if (!withStudent && this.isWithStudent()) {
                this.isWithStudent.release();
                this.isAvailable.release();
            }
            notifyAll();
            System.out.println("TA is with a student: " + isWithStudent());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    /**
     * The TA will sleep until the line is not empty. Then the TA will wake up.
     */
    public synchronized void nap() {

        try {
            System.out.println("TA is sleeping");
            // System.out.println(this.toString());
            while (OfficeHours.isLineEmpty()) {
                wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("OfficeHours.isLineEmpty: " + OfficeHours.isLineEmpty());
        System.out.println("Ta is awake.");
        setAsleep(false);
        System.out.println("Ta is available");
        setIsAvailable(true);
        notifyAll();
    }

    /**
     * The TA waits for students to come into the office, then helps them, and then waits for the
     * students to leave the office. TA goes back to sleep once the line is empty.
     */
    public synchronized void helpStudents() {
        while (!OfficeHours.isLineEmpty()) {
            try {
                System.out.println("TA waiting for students in line to come into office.");
                while (isAvailable()) {
                    wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                System.out.println("TA is helping a student.");
                while (isWithStudent()) {
                    wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("OfficeHours line is empty: " + OfficeHours.isLineEmpty());
        System.out.println("TA is done helping students.");
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("\n\n");
        sb.append("*******************************\n");
        sb.append(" TA State \n");
        sb.append("*******************************\n");
        sb.append("isAvailable: " + isAvailable() + "\n");
        sb.append("isAsleep: " + isAsleep() + "\n");
        sb.append("OfficeHours.isLineEmpty(): " + OfficeHours.isLineEmpty() + "\n");
        sb.append("\n");
        sb.append("\n\n");

        return sb.toString();
    }

    /**
     * The teacher naps until the Hallway.line is not empty. Then helps a random number of students
     * until the line becomes empty again.
     */
    @Override
    public void run() {
        while (true) {
            nap();
            helpStudents();
        }
    }

}
