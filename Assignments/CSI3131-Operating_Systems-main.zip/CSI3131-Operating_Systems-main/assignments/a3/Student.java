
// @formatter:off
/**
 * Course: CSI3131 - Operating Systems
 * Professor: Dr. Fadi Malek - Malek@uOttawa.ca
 * Semester: Summer 2022
 * 
 * @author Kian Zahrai - 300098986
 * @author Billy Bolton - 6411144
 * @since 2022-06-26
 */
// @formatter:on

import java.util.concurrent.Semaphore;

/**
 * The Student class is a class that represents a student. It has a unique ID, and three semaphores:
 * needsHelp, inLine, and gettingHelp.
 */
public class Student implements Runnable {

    private final long ID;
    private Semaphore needsHelp;
    private Semaphore inLine;
    private Semaphore gettingHelp;

    // This is the constructor for the Student class. It initializes the ID of the student, and
    // creates three semaphores: needsHelp, inLine, and gettingHelp.
    public Student(int ID) {
        this.ID = ID;
        needsHelp = new Semaphore(1);
        inLine = new Semaphore(1);
        gettingHelp = new Semaphore(1);
    }


    /**
     * This function returns the ID of the current object
     * 
     * @return The ID of the object.
     */
    public long getId() {
        return this.ID;
    }


    /**
     * If the number of available permits is 0, then the semaphore is locked and the function
     * returns true.
     * 
     * @return If the number of available permits is 0.
     */
    private boolean needsHelp() {
        return this.needsHelp.availablePermits() == 0;
    }

    /**
     * If the number of available permits is 0, then the student is in line.
     * 
     * @return If the number of available permits is 0.
     */
    private boolean isInLine() {
        return this.inLine.availablePermits() == 0;
    }

    /**
     * If the number of available permits is 0, then the student is getting help.
     * 
     * @return The number of permits available.
     */
    private boolean isGettingHelp() {
        return this.gettingHelp.availablePermits() == 0;
    }

    /**
     * If the student needs help, acquire the semaphore, and if the student doesn't need help,
     * release the semaphore
     * 
     * @param needsHelp a boolean value that is used to set whether the student needs help or not.
     */
    private void setNeedsHelp(boolean needsHelp) {
        try {
            if (needsHelp && !this.needsHelp()) {
                this.needsHelp.acquire();

            }
            if (!needsHelp && this.needsHelp()) {
                this.needsHelp.release();
            }
            System.out.println("Student " + getId() + " needs help: " + needsHelp());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * If the student is not in line and the line is not full, the student acquires a chair and
     * enters the line. If the student is in line and the line is not empty, the student releases
     * the chair and leaves the line
     * 
     * @param inLine a value that is used to set whether the student is in line or not
     */
    public synchronized void setInLine(boolean inLine) {
        synchronized (this) {
            try {
                if (inLine && !isInLine() && !OfficeHours.isLineFull()) {
                    this.inLine.acquire();
                    OfficeHours.acquireChair();
                }
                if (!inLine && isInLine() && !OfficeHours.isLineEmpty()) {

                    try {
                        while (!OfficeHours.isTaAvailable()) {
                            wait();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    this.inLine.release();
                    OfficeHours.releaseChair();
                }

                OfficeHours.notifyTa();
                notifyAll();
                System.out.println(
                        "Student " + getId() + " is in waiting line for help: " + isInLine());
                System.out.println("OfficeHours size: " + OfficeHours.getLineSize());
            } catch (

            InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * If the student is getting help, then acquire the gettingHelp semaphore. If the student is not
     * getting help, then release the gettingHelp semaphore
     * 
     * @param gettingHelp a value that is used to set whether the student is getting help or not.
     */
    public void setGettingHelp(boolean gettingHelp) {
        try {
            if (gettingHelp && !isGettingHelp()) {
                this.gettingHelp.acquire();
            }
            if (!gettingHelp && isGettingHelp()) {
                this.gettingHelp.release();
            }
            System.out.println("Student " + getId() + " getting help: " + isGettingHelp());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * The student waits until the TA is available, then acquires the TA
     */
    public synchronized void acquireTa() {
        try {
            while (!OfficeHours.isTaAvailable()) {
                wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Student " + getId() + " acquiring TA.");
        OfficeHours.acquireTa();
    }

    /**
     * The student waits until the TA is with them (as a sanity check), then releases the TA
     */
    public synchronized void releaseTa() {
        try {
            while (!OfficeHours.isTaWithStudent()) {
                wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        OfficeHours.releaseTa();
        System.out.println("Student " + getId() + " is releasingTA.");
    }

    /**
     * Student X is programming. Student pauses for a random amount of time. Student X is done
     * programming.
     */
    public void program() {
        System.out.println("Student " + getId() + " is programming.");
        pause();
        System.out.println("Student " + getId() + " is done programming.");
    }

    /**
     * If the student needs help, the student will wait until the TA is available, then acquire the
     * TA, get help, and release the TA. If the line is full, the student will go back to
     * programming.
     */
    public synchronized void getHelp() {
        setNeedsHelp(true);
        while (needsHelp()) {

            // Needs help but line is full. Back to programming.
            if (OfficeHours.isLineFull()) {
                System.out.println("LINE IS FULL. Student " + getId() + " is back to programming.");
                setNeedsHelp(false);
                pause();
                pause();
                return;
            }

            System.out.println("Student " + getId() + " is acquiring chair.");
            setInLine(true);
            pause();


            // Student is in line for TA
            System.out.println("Student " + getId() + " is waiting for TA to be available.");
            System.out.println("TA is available: " + OfficeHours.isTaAvailable());
            while (isInLine() && !OfficeHours.isTaAvailable()) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            pause();

            System.out.println("Student " + getId() + " is releasing chair.");
            setInLine(false);


            acquireTa();
            setGettingHelp(true);
            notifyAll();

            pause();

            System.out.println("Student " + getId() + " is done getting help.");
            setGettingHelp(false);
            setNeedsHelp(false);
            releaseTa();
            notifyAll();
        }
        System.out.println("Student " + getId() + " is back to programming.");
        pause();
    }

    /**
     * The student pauses for a random amount of time.
     */
    public void pause() {
        try {
            // System.out.println("Student " + getId() + " is pausing.");
            Thread.sleep(Utils.randomSleepTime());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n\n");
        sb.append("*******************************\n");
        sb.append(" Student State \n");
        sb.append("*******************************\n");
        sb.append("Id: " + getId());
        sb.append("\n");
        sb.append("Needs Help: " + needsHelp());
        sb.append("\n");
        sb.append("Waiting In Line: " + isInLine());
        sb.append(OfficeHours.hallwayState());
        sb.append("\n\n");
        return sb.toString();
    }


    /**
     * A function that runs alternates the student from programming and getting help.
     */
    @Override
    public void run() {
        while (true) {
            program();
            getHelp();
        }
    }

}
