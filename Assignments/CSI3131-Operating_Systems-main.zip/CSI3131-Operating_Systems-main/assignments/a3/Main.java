
// @formatter:off
/**
 * Course: CSI3131 - Operating Systems
 * Professor: Dr. Fadi Malek - Malek@uOttawa.ca
 * Semester: Summer 2022
 * 
 * @author Kian Zahrai - 300098986
 * @author Billy Bolton - 6411144
 * @since 2022-06-26
 */
// @formatter:on

import java.util.Scanner;

/**
 * The main method asks the user for an integer greater than 0, and then generates that many
 * students. Will then begin the OfficeHours simulation.
 */
public class Main {

    /**
     * Generates a random number of students and starts the office hours.
     */
    public static void main(String[] args) {

        int n = getIntegerInput();
        generateStudents(n);

        OfficeHours.start();

    }

    /**
     * This function asks the user for an integer greater than 0, and returns that integer
     * 
     * @return The method is returning the integer that the user inputs.
     */
    public static int getIntegerInput() {
        // while statement that keeps asking for input when args is < 0
        System.out.println("Enter an integer greater than 0: ");
        Scanner input;
        int num;
        while (true) {
            input = new Scanner(System.in);
            num = input.nextInt();
            if (num > 0) {
                break;
            }
        }
        System.out.println("\n");
        input.close();
        return num;
    }

    /**
     * For each student, create a new thread that runs the Student class.
     * 
     * @param n the number of students to generate
     */
    public static void generateStudents(int n) {
        // for loop that creates n students
        for (int i = 0; i < n; i++) {
            Thread student = new Thread(new Student(i));
            student.start();
        }
    }

}
