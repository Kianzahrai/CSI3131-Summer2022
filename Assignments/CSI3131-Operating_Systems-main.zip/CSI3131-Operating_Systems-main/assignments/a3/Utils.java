
// @formatter:off
/**
 * Course: CSI3131 - Operating Systems
 * Professor: Dr. Fadi Malek - Malek@uOttawa.ca
 * Semester: Summer 2022
 * 
 * @author Kian Zahrai - 300098986
 * @author Billy Bolton - 6411144
 * @since 2022-06-26
 */
// @formatter:on

/**
 * This class contains a method that returns a random number between 0 and 10,000.
 */
public class Utils {

    /**
     * Return a random number between 0 and 10,000.
     * 
     * @return A random number between 0 and 10000.
     */
    public static long randomSleepTime() {
        return (long) (Math.random() * 10000);
    }

}
