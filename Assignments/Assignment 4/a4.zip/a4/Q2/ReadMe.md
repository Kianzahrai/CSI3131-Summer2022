From this directory of any question folder: type the following in the command line to run the program.
`clear && javac *.java -d . && java Q2.Main`
